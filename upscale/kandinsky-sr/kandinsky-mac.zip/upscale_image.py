"""Run the locally installed ImageSR model on Apple Silicon."""
import argparse
import json
import time
from pathlib import Path

import torch
from PIL import Image
from kandinsky_image_sr import KandinskyImageSRPipeline

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--scale', type=int, choices=(2, 4), default=2)
    args = parser.parse_args()
    if args.input.resolve() == args.output.resolve():
        parser.error('choose a separate output file')

    base = Path(__file__).resolve().parent
    image = Image.open(args.input).convert('RGB')
    pipeline = KandinskyImageSRPipeline.from_pretrained(
        str(base / 'models/image'), dtype=torch.bfloat16, local_files_only=True,
    ).to('mps')
    torch.mps.synchronize()
    start = time.perf_counter()
    with torch.autocast('mps', dtype=torch.bfloat16):
        result = pipeline(image, upscale_factor=args.scale).images[0]
    torch.mps.synchronize()
    elapsed = time.perf_counter() - start
    assert result.size == tuple(size * args.scale for size in image.size)
    result.save(args.output)
    print(json.dumps(dict(input=image.size, output=result.size, seconds=elapsed)))

if __name__ == '__main__':
    main()

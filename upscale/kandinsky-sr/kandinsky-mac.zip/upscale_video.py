"""Upscale a 25-frame excerpt at 24 fps with local Kandinsky VSR weights."""
import argparse
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

os.environ.setdefault("TORCH_COMPILE_DISABLE", "1")
os.environ.setdefault("HF_HUB_OFFLINE", "1")
os.environ.setdefault("PYTORCH_ENABLE_MPS_FALLBACK", "1")

import numpy as np
import torch
from PIL import Image
from kandinsky_sr.pipeline.config import SRConfig
from kandinsky_sr.pipeline.factory import load_sr_pipeline
from mps_attention import install

FPS = 24
FRAMES = 25


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--start", type=float, default=0, help="excerpt start in seconds")
    args = parser.parse_args()
    if not args.input.is_file() or args.start < 0:
        parser.error("choose an existing input and a non-negative start time")
    if args.output.exists() or args.output.suffix.lower() != ".mp4":
        parser.error("choose a new .mp4 output path")
    ffmpeg = os.environ.get("FFMPEG_BIN") or shutil.which("ffmpeg")
    if not ffmpeg:
        parser.error("put ffmpeg on PATH or set FFMPEG_BIN to its executable")
    if not torch.backends.mps.is_available():
        parser.error("Apple MPS is unavailable")
    base = Path(__file__).resolve().parent
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=args.output.parent) as folder:
        temp = Path(folder)
        cmd = [ffmpeg, "-v", "error", "-nostdin"]
        source = ["-ss", str(args.start), "-i", str(args.input)]
        subprocess.run(cmd + source + ["-map", "0:v:0", "-vf", "fps=24", "-frames:v", str(FRAMES),
                       str(temp / "%03d.png")], check=True)
        files = sorted(temp.glob("*.png"))
        if len(files) != FRAMES:
            parser.error("the excerpt needs 25 frames at 24 fps; choose an earlier start")
        frames = []
        for file in files:
            with Image.open(file) as image:
                frames.append(np.asarray(image.convert("RGB")))
        video = torch.from_numpy(np.stack(frames)).permute(0, 3, 1, 2).contiguous()
        install()
        config = SRConfig(checkpoint_path=str(base / "models/video"), device="mps",
                          num_steps=2, vae_backend="torch", nabla="flex", lu_load_scales=("2x",))
        pipe = load_sr_pipeline(config, "mps", force=True, resolution_scale=2)
        with torch.inference_mode(), torch.autocast("mps", dtype=torch.bfloat16):
            result = pipe(video=video, seed=42, show_progress=True).frames[0]
        result = result.permute(1, 2, 3, 0).cpu().numpy()
        h, w = video.shape[-2:]
        if result.shape != (FRAMES, 2*h, 2*w, 3) or result.dtype != np.uint8:
            raise RuntimeError(f"unexpected model output: {result.shape}, {result.dtype}")
        encoded = temp / "clip.mp4"
        encode = cmd + ["-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{2*w}x{2*h}",
                        "-r", str(FPS), "-i", "-"] + source + [
                        "-map", "0:v:0", "-map", "1:a:0?", "-t", str(FRAMES/FPS),
                        "-c:v", "libx264", "-crf", "16", "-preset", "fast", "-pix_fmt", "yuv420p",
                        "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", str(encoded)]
        with subprocess.Popen(encode, stdin=subprocess.PIPE) as proc:
            for frame in result:
                proc.stdin.write(frame.tobytes())
            proc.stdin.close()
            if proc.wait():
                raise RuntimeError("FFmpeg could not encode the clip")
        os.link(encoded, args.output)
    print(args.output)


if __name__ == "__main__":
    main()

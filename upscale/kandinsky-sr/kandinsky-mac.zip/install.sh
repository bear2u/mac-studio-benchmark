#!/bin/bash
# Install the versions used for the Mac MPS benchmark in this directory.
set -euo pipefail
cd "$(dirname "$0")"
for tool in git uv ffmpeg; do
  command -v "$tool" >/dev/null || { echo "Missing command: $tool" >&2; exit 1; }
done
checkout() {
  local directory=$1 repository=$2 revision=$3
  if [ -e "$directory" ]; then
    test "$(git -C "$directory" rev-parse HEAD)" = "$revision" ||
      { echo "Different checkout in $directory. Choose a fresh install directory." >&2; exit 1; }
  else
    git clone "$repository" "$directory"
    git -C "$directory" checkout --detach "$revision"
  fi
}
checkout image-source https://github.com/kandinskylab/kandinsky-image-sr.git 6c2405796cf7576b0cffff27acd103d667b91ca8
checkout video-source https://github.com/kandinskylab/kandinsky-video-sr.git 2c9f25d32c78ce90795fb6fc59e4aaa6e6d41f09
if [ ! -x .venv/bin/python ]; then uv venv --python 3.13.18 .venv; fi
uv pip install --python .venv/bin/python --constraint versions.txt ./image-source ./video-source
.venv/bin/python -c 'import torch; print("torch", torch.__version__, "MPS", torch.backends.mps.is_available()); assert torch.backends.mps.is_available(), "Apple MPS unavailable"'
mkdir -p models/image models/video results
.venv/bin/hf download kandinskylab/Kandinsky-ImageSR-2.0 --revision 7d5b5ed7def0b45b98f398c0b295a6b1658863db --exclude 'assets/*' --local-dir models/image
.venv/bin/hf download kandinskylab/Kandinsky-6.0-VSR-2.0-distilled2steps-Diffusers --revision 97dec7ebe8b617aecbaac1938d265c7b6cdb35a3 --exclude 'assets/*' --local-dir models/video

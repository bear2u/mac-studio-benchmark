"""Run the released single-clip NABLA attention mask through Apple MPS SDPA."""
import torch
from torch.nn import functional as F

from kandinsky_sr.core.components.model import nn as model_nn
from kandinsky_sr.core.components.model.utils import fast_sta_nabla


def pack_heads(tensor):
    return tensor.transpose(0, 1).unsqueeze(0).contiguous()


def dense(self, query, key, value, cu_seqlens, cond_cu_seqlens=None, *, return_attn_probs=False):
    if return_attn_probs:
        raise NotImplementedError("This inference path returns only attention outputs")
    query_bounds = cu_seqlens.tolist()
    key_bounds = (cu_seqlens if cond_cu_seqlens is None else cond_cu_seqlens).tolist()
    output = []
    for start, end, key_start, key_end in zip(query_bounds, query_bounds[1:], key_bounds, key_bounds[1:]):
        attended = F.scaled_dot_product_attention(
            pack_heads(query[start:end]), pack_heads(key[key_start:key_end]), pack_heads(value[key_start:key_end])
        )
        output.append(attended[0].transpose(0, 1).flatten(1))
    return torch.cat(output)


def sparse(self, query, key, value, sparse_params=None, *, return_sparsity=False):
    params = sparse_params
    if return_sparsity or len(params["visual_seqlens"]) != 2 or params["method"] != "topcdf" or "mf" in params:
        raise NotImplementedError("The MPS adapter handles the released single-clip top-CDF inference configuration")

    time, height, width = params["visual_shape"]
    query, key, value = map(pack_heads, (query, key, value))
    pooled_query, pooled_key = (tensor.unflatten(2, (-1, 64)).mean(3) for tensor in (query, key))
    scores = ((pooled_query @ pooled_key.transpose(-2, -1)) / query.shape[-1] ** 0.5).softmax(-1)
    sorted_scores, indices = scores.sort(-1)
    selected = sorted_scores.cumsum(-1) >= 1 - params["P"]
    mask = selected.to(torch.int32).gather(-1, indices.argsort(-1)).bool()
    if params["add_sta"]:
        mask |= fast_sta_nabla(
            time, height // 8, width // 8, params["wT"], params["wH"], params["wW"], device=query.device
        )

    # Expand only four 64-token query blocks at a time to bound MPS memory.
    attended = []
    for start in range(0, mask.shape[2], 4):
        stop = start + 4
        block_mask = mask[:, :, start:stop].repeat_interleave(64, dim=2).repeat_interleave(64, dim=3)
        attended.append(
            F.scaled_dot_product_attention(query[:, :, 64 * start:64 * stop], key, value, attn_mask=block_mask)
        )
    return torch.cat(attended, 2)[0].transpose(0, 1).flatten(1)


def install():
    model_nn.MultiheadCrossAttention.scaled_dot_product_attention = dense
    model_nn.MultiheadSelfAttention.scaled_dot_product_attention = dense
    model_nn.MultiheadSelfAttention.attention_flex = sparse
